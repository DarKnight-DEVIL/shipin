import { Timestamp } from "firebase/firestore";

export type RequestStatus =
  | "submitted"
  | "review"
  | "payment"
  | "awaiting_payment"
  | "paid"
  | "purchased"
  | "warehouse_received"
  | "packed"
  | "shipped"
  | "out_for_delivery"
  | "delivered"
  | "refunded";

export interface RequestItem {
  name: string;
  quantity: number;
  url?: string;

  unitPrice?: number;
  subtotal?: number;
}

export interface QuoteBreakdown {
  productsTotal: number;
  domesticShipping: number;
  internationalShipping: number;
  serviceFee: number;
  grandTotal: number;
}

export interface Quote {
  version: number;

  items: RequestItem[];

  breakdown: QuoteBreakdown;

  serviceFeeRule?: string;

  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface Tracking {
  carrier: string;
  trackingNumber: string;
  trackingUrl?: string;
  estimatedDelivery?: string;
}

export interface Payment {
  provider: "paypal";

  orderId: string;
  captureId?: string;

  amount: number;
  currency?: string;

  paidAt?: Timestamp;
}

export interface WarehouseInspection {
  weight?: number;

  length?: number;
  width?: number;
  height?: number;

  condition?: string;

  photos?: string[];

  notes?: string;

  receivedAt?: Timestamp;
}

export interface Request {
  id: string;

  userId: string;

  email: string;

  status: RequestStatus;

  items: RequestItem[];

  quote?: Quote;

  payment?: Payment;

  tracking?: Tracking;

  warehouse?: WarehouseInspection;

  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}