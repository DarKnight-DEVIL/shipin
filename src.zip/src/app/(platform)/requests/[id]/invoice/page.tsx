"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

import { getRequestById } from "@/lib/firestore";

import LoadingCard from "@/components/ui/LoadingCard";
import InvoicePreview from "@/components/invoice/InvoicePreview";
import PayPalCheckout from "@/components/payment/PayPalCheckout";

export default function InvoicePage() {
  const { id } = useParams();

  const [request, setRequest] = useState<any>(null);

  useEffect(() => {
    async function load() {
      if (!id) return;

      const data = await getRequestById(id as string);

      setRequest(data);
    }

    load();
  }, [id]);

  if (!request) {
    return <LoadingCard />;
  }

  if (!request.quote) {
    return (
      <div className="p-8 text-white">
        Invoice not available yet.
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-8 space-y-8">

      <InvoicePreview
        invoice={{
          id: request.id.slice(0, 8),
          ...request.quote,
          email: request.email,
          customerName: request.name,
          requestId: request.id,
        }}
      />

      {request.status !== "purchase_invoice_paid" && (
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6">

          <h2 className="text-2xl font-bold text-white mb-4">
            Secure Payment
          </h2>

          <PayPalCheckout
            requestId={request.id}
            amount={request.quote.grandTotal}
          />

        </div>
      )}

    </div>
  );
}