import { NextResponse } from "next/server";
import { getRequestById } from "@/lib/firestore";
import { paypalClient } from "@/lib/paypal";

export async function POST(req: Request) {
  try {
    const { requestId } = await req.json();

    const request = await getRequestById(requestId);

    if (!request?.quote) {
      return NextResponse.json(
        { error: "Invoice not found" },
        { status: 404 }
      );
    }

    const amount =
      request.quote.grandTotal.toFixed(2);

    const response =
      await paypalClient.ordersController.createOrder({
        body: {
          intent: "CAPTURE",

          purchaseUnits: [
            {
              referenceId: requestId,

              amount: {
                currencyCode: "USD",
                value: amount,
              },
            },
          ],
        },
      });

    return NextResponse.json({
      orderID: response.result.id,
    });
  } catch (err) {
    console.error(err);

    return NextResponse.json(
      { error: "Unable to create order." },
      { status: 500 }
    );
  }
}