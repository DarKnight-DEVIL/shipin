import { NextResponse } from "next/server";
import { paypalClient } from "@/lib/paypal";

import {
  doc,
  updateDoc,
  serverTimestamp,
} from "firebase/firestore";

import { db } from "@/lib/firebase";

export async function POST(req: Request) {
  try {
    const {
      requestId,
      orderID,
    } = await req.json();

    const response =
      await paypalClient.ordersController.captureOrder({
        id: orderID,
      });

    const capture =
      response.result.purchaseUnits?.[0]
        ?.payments?.captures?.[0];

    if (
      capture?.status !==
      "COMPLETED"
    ) {
      return NextResponse.json(
        {
          error:
            "Payment not completed.",
        },
        { status: 400 }
      );
    }

    await updateDoc(
      doc(db, "requests", requestId),
      {
        status:
          "purchase_invoice_paid",

        payment: {
          provider: "paypal",

          orderID,

          captureID:
            capture.id,

          amount:
            capture.amount?.value,

          currency:
            capture.amount
              ?.currencyCode,

          paidAt:
            serverTimestamp(),
        },

        updatedAt:
          serverTimestamp(),
      }
    );

    return NextResponse.json({
      success: true,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        error:
          "Unable to capture payment.",
      },
      {
        status: 500,
      }
    );
  }
}