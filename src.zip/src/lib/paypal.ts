import {
  Client,
  Environment,
  LogLevel,
} from "@paypal/paypal-server-sdk";

const environment =
  process.env.PAYPAL_ENV === "live"
    ? Environment.Production
    : Environment.Sandbox;

export const paypalClient = new Client({
  clientCredentialsAuthCredentials: {
    oAuthClientId:
      process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID!,
    oAuthClientSecret:
      process.env.PAYPAL_CLIENT_SECRET!,
  },

  environment,

  logging: {
    logLevel: LogLevel.Info,
    logRequest: true,
    logResponse: true,
  },
});