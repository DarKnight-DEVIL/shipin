import type { Request } from "@/types/request";

interface Props {
    request: Request;
}

const styles: Record<
  string,
  string
> = {
  submitted:
    "bg-blue-500/10 text-blue-400",

  purchase_invoice_sent:
    "bg-yellow-500/10 text-yellow-400",

  purchase_invoice_paid:
    "bg-green-500/10 text-green-400",

  items_ordered:
    "bg-purple-500/10 text-purple-400",

  warehouse_received:
    "bg-orange-500/10 text-orange-400",

  shipping_invoice_sent:
    "bg-cyan-500/10 text-cyan-400",

  shipping_invoice_paid:
    "bg-teal-500/10 text-teal-400",

  shipped:
    "bg-indigo-500/10 text-indigo-400",

  delivered:
    "bg-green-600/10 text-green-500",
};

export default function StatusBadge({
  status,
}: Props) {
  return (
    <span
      className={`inline-flex rounded-full px-3 py-1 text-sm font-semibold ${
        styles[status] ??
        "bg-slate-700 text-white"
      }`}
    >
      {status
        .replaceAll("_", " ")
        .replace(
          /\b\w/g,
          (c) => c.toUpperCase()
        )}
    </span>
  );
}