"use client";

interface Props {
  status: string;
}

const TIMELINE = [
  "submitted",
  "review",
  "payment",
  "awaiting_payment",
  "paid",
  "purchased",
  "warehouse_received",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
];

const LABELS: Record<string, string> = {
  submitted: "Request Received",
  review: "Reviewing Products",
  payment: "Quote Ready",
  awaiting_payment: "Awaiting Payment",
  paid: "Payment Confirmed",
  purchased: "Items Purchased",
  warehouse_received: "Arrived at ShipIN Warehouse",
  packed: "Preparing Shipment",
  shipped: "In Transit",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered Successfully",
};

export default function RequestTimeline({
  status,
}: Props) {
  const currentIndex =
    status === "refunded"
      ? -1
      : TIMELINE.indexOf(status);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

      <h2 className="text-2xl font-semibold text-white mb-6">
        Shipment Progress
      </h2>

      <div className="space-y-4">

        {TIMELINE.map((step, index) => {

          const completed =
            index <= currentIndex;

          const active =
            index === currentIndex;

          return (

            <div
              key={step}
              className="flex items-center gap-4"
            >

              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  completed
                    ? "bg-green-500 text-white"
                    : "bg-slate-800 text-slate-500"
                }`}
              >
                {completed
                  ? "✓"
                  : index + 1}
              </div>

              <div>

                <div
                  className={`font-medium ${
                    completed
                      ? "text-white"
                      : "text-slate-500"
                  } ${
                    active
                      ? "text-green-400"
                      : ""
                  }`}
                >
                  {LABELS[step]}
                </div>

              </div>

            </div>

          );
        })}

      </div>

    </div>
  );
}