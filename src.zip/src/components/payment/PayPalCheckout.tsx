"use client";

import {
  PayPalButtons,
} from "@paypal/react-paypal-js";

import { paymentService } from "@/features/payment/services/paymentService";

type PaymentType = "main" | "additional_item";

interface Props {
  requestId: string;

  amount: number;

  paymentType?: PaymentType;

  additionalItemRequestId?: string;

  onSuccess?: () => Promise<void> | void;

  onError?: (error: unknown) => void;

  disabled?: boolean;
}

export default function PayPalCheckout({
  requestId,
  amount,
  paymentType = "main",
  additionalItemRequestId,
  onSuccess,
  onError,
  disabled = false,
}: Props) {
  if (amount <= 0) {
    return null;
  }

  return (
    <div className="space-y-3">

      <PayPalButtons
        disabled={disabled}
        forceReRender={[amount]}
        style={{
          layout: "vertical",
          color: "gold",
          shape: "rect",
          label: "paypal",
          height: 50,
          disableMaxWidth: true,
        }}

        createOrder={async () => {
          try {
            const order =
              await paymentService.createPayPalOrder(
                requestId,
                paymentType,
                additionalItemRequestId
              );
            console.log("Returned order:", order);
            return order.id;
          } catch (err) {
            console.error(err);
            throw err;
          }
        }}

        onApprove={async (data) => {
          try {
            console.log("PayPal onApprove data:", data);

            await paymentService.capturePayPalOrder(
              requestId,
              data.orderID,
              paymentType,
              additionalItemRequestId
            );

            if (onSuccess) {
              await onSuccess();
            }

          } catch (err) {

            console.error(err);

            alert(
              "Payment succeeded but finalization failed."
            );

          }
        }}

        onError={(err) => {

          console.error(err);

          if (onError) {
            onError(err);
          } else {
            alert(
              "Unable to process PayPal payment."
            );
          }

        }}
      />

    </div>
  );
}