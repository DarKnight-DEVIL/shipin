"use client";

import { useState } from "react";

import type { Request } from "@/types/request";
import Section from "@/components/ui/Section";
import ActionButton from "@/components/ui/ActionButton";

interface Props {
  request: Request;
}

export default function WarehousePanel({
  request,
}: Props) {
  const [weight, setWeight] = useState(
    request.warehouse?.weight ?? ""
  );

  const [length, setLength] = useState(
    request.warehouse?.length ?? ""
  );

  const [width, setWidth] = useState(
    request.warehouse?.width ?? ""
  );

  const [height, setHeight] = useState(
    request.warehouse?.height ?? ""
  );

  const [condition, setCondition] =
    useState(
      request.warehouse?.condition ??
        "Good"
    );

  return (
    <Section
      title="Warehouse Inspection"
      subtitle="Inspect package after arrival"
    >
      <div className="grid md:grid-cols-2 gap-5">

        <Input
          label="Weight (kg)"
          value={weight}
          onChange={setWeight}
        />

        <Input
          label="Length (cm)"
          value={length}
          onChange={setLength}
        />

        <Input
          label="Width (cm)"
          value={width}
          onChange={setWidth}
        />

        <Input
          label="Height (cm)"
          value={height}
          onChange={setHeight}
        />

      </div>

      <div className="mt-6">

        <label className="block text-sm text-slate-400 mb-2">
          Package Condition
        </label>

        <select
          value={condition}
          onChange={(e) =>
            setCondition(e.target.value)
          }
          className="w-full rounded-xl bg-slate-900 border border-slate-700 px-4 py-3 text-white"
        >
          <option>Excellent</option>
          <option>Good</option>
          <option>Damaged</option>
        </select>

      </div>

      <div className="mt-8">

        <ActionButton
          className="w-full"
        >
          Save Inspection
        </ActionButton>

      </div>

    </Section>
  );
}

interface InputProps {
  label: string;
  value: string | number;
  onChange: (value: string) => void;
}

function Input({
  label,
  value,
  onChange,
}: InputProps) {
  return (
    <div>

      <label className="block text-sm text-slate-400 mb-2">
        {label}
      </label>

      <input
        value={value}
        onChange={(e) =>
          onChange(e.target.value)
        }
        className="w-full rounded-xl bg-slate-900 border border-slate-700 px-4 py-3 text-white"
      />

    </div>
  );
}