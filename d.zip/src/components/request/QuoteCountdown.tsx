"use client";

import { useEffect, useState } from "react";
import { Timestamp } from "firebase/firestore";
import {
  getRemainingTime,
} from "@/lib/quoteExpiry";

interface Props {
  expiresAt: Timestamp | Date | string;
}

export default function QuoteCountdown({
  expiresAt,
}: Props) {
  const [time, setTime] =
    useState(
      getRemainingTime(expiresAt)
    );

  useEffect(() => {
    const interval =
      setInterval(() => {
        setTime(
          getRemainingTime(expiresAt)
        );
      }, 1000);

    return () =>
      clearInterval(interval);
  }, [expiresAt]);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">

      <h3 className="text-white font-semibold mb-3">
        Quote Expires In
      </h3>

      <div className="text-4xl font-bold text-green-400">

        {String(time.hours).padStart(2, "0")}:

        {String(time.minutes).padStart(2, "0")}:

        {String(time.seconds).padStart(2, "0")}

      </div>

    </div>
  );
}