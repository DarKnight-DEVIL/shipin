"use client";

import PhoneInput from "react-phone-number-input";

import "react-phone-number-input/style.css";

interface Props {
  value: string;
  onChange: (value: string) => void;
}

export default function InternationalPhoneInput({
  value,
  onChange,
}: Props) {
  return (
    <PhoneInput
      defaultCountry="IN"
      international
      value={value}
      onChange={(value) =>
        onChange(value ?? "")
      }
      className="bg-slate-900 rounded-xl p-3"
    />
  );
}