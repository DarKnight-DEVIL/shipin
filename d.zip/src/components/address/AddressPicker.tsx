"use client";

import type { Address } from "@/types/address";

interface Props {
  addresses: Address[];
  selected?: Address;
  onSelect: (address: Address) => void;
  onAddNew: () => void;
}

export default function AddressPicker({
  addresses,
  selected,
  onSelect,
  onAddNew,
}: Props) {
  return (
    <div className="space-y-4">

      {addresses.map((address) => (

        <button
          key={address.id}
          type="button"
          onClick={() => onSelect(address)}
          className={`w-full text-left rounded-xl border p-4 transition ${
            selected?.id === address.id
              ? "border-purple-500 bg-purple-500/10"
              : "border-slate-800 bg-slate-900"
          }`}
        >

          <div className="flex justify-between">

            <div>

              <h3 className="text-white font-semibold">
                {address.label}

                {address.isDefault && (
                  <span className="ml-2 text-green-400">
                    ★ Default
                  </span>
                )}

              </h3>

              <p className="text-slate-400 mt-2">
                {address.recipientName}
              </p>

              <p className="text-slate-500">
                {address.addressLine1}
              </p>

              <p className="text-slate-500">
                {address.city}, {address.state}
              </p>

            </div>

          </div>

        </button>

      ))}

      <button
        type="button"
        onClick={onAddNew}
        className="w-full rounded-xl border-2 border-dashed border-slate-700 py-4 hover:border-purple-500"
      >
        + Add New Address
      </button>

    </div>
  );
}