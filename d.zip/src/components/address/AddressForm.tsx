"use client";

import { useState } from "react";
import type { Address } from "@/types/address";

// Step 6.1: Added custom select and phone input imports
import CountrySelect from "./CountrySelect";
import InternationalPhoneInput from "./PhoneInput";

interface Props {
  initialData?: Partial<Address>;
  onSubmit: (
    data: Omit<Address, "id" | "createdAt" | "updatedAt">
  ) => Promise<void>;
}

export default function AddressForm({
  initialData,
  onSubmit,
}: Props) {
  const [form, setForm] = useState({
    label: initialData?.label ?? "",
    recipientName: initialData?.recipientName ?? "",
    phone: initialData?.phone ?? "",
    email: initialData?.email ?? "",
    // Expects ISO 3166-1 alpha-2 format strings (e.g. "IN", "US", "GB")
    country: initialData?.country ?? "", 
    state: initialData?.state ?? "",
    city: initialData?.city ?? "",
    postalCode: initialData?.postalCode ?? "",
    addressLine1: initialData?.addressLine1 ?? "",
    addressLine2: initialData?.addressLine2 ?? "",
    isDefault: initialData?.isDefault ?? false,
  });

  const update = (
    key: keyof typeof form,
    value: string | boolean
  ) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <form
      onSubmit={async (e) => {
        e.preventDefault();
        await onSubmit(form);
      }}
      className="space-y-5 text-white"
    >
      <input
        value={form.label}
        onChange={(e) => update("label", e.target.value)}
        placeholder="Label (Home, Office...)"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      <input
        value={form.recipientName}
        onChange={(e) => update("recipientName", e.target.value)}
        placeholder="Recipient Name"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      {/* Step 6.2: Swapped out phone text input for unified international configuration */}
      <InternationalPhoneInput
        value={form.phone}
        onChange={(value) => update("phone", value)}
      />

      <input
        value={form.email}
        onChange={(e) => update("email", e.target.value)}
        placeholder="Email"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      {/* Step 6.3 & 6.5: Managed regional layout selection through ISO uppercase state codes */}
      <CountrySelect
        value={form.country}
        onChange={(value) => update("country", value)}
      />

      <input
        value={form.state}
        onChange={(e) => update("state", e.target.value)}
        placeholder="State"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      <input
        value={form.city}
        onChange={(e) => update("city", e.target.value)}
        placeholder="City"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      <input
        value={form.postalCode}
        onChange={(e) => update("postalCode", e.target.value)}
        placeholder="Postal Code"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      <textarea
        value={form.addressLine1}
        onChange={(e) => update("addressLine1", e.target.value)}
        placeholder="Address Line 1"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      <textarea
        value={form.addressLine2}
        onChange={(e) => update("addressLine2", e.target.value)}
        placeholder="Address Line 2 (Optional)"
        className="w-full bg-slate-900 rounded-xl p-3"
      />

      <label className="flex gap-3 items-center text-white cursor-pointer select-none">
        <input
          type="checkbox"
          checked={form.isDefault}
          onChange={(e) => update("isDefault", e.target.checked)}
        />
        Make Default Address
      </label>

      <button
        type="submit"
        className="bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-xl w-full font-semibold transition-colors"
      >
        Save Address
      </button>
    </form>
  );
}