"use client";

import Select from "react-select";
import { Country } from "country-state-city";

interface Props {
  value: string;
  onChange: (value: string) => void;
}

export default function CountrySelect({
  value,
  onChange,
}: Props) {

  const countries = Country.getAllCountries().map(
    (country) => ({
      value: country.isoCode,
      label: `${country.flag} ${country.name}`,
    })
  );

  return (
    <Select
      options={countries}
      value={
        countries.find(
          (c) => c.value === value
        ) ?? null
      }
      onChange={(option) =>
        onChange(option?.value ?? "")
      }
      placeholder="Select Country"
      className="text-black"
    />
  );
}