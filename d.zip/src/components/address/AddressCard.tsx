"use client";

import {
  deleteAddress,
  setDefaultAddress,
} from "@/lib/addressBook";

import { auth } from "@/lib/firebase";

// Step 5.1: Updated interface with onEdit and onRefresh
interface Props {
  address: any;
  onEdit: (address: any) => void;
  onRefresh: () => Promise<void>;
}

// Step 5.2: Destructured the new props in the component signature
export default function AddressCard({
  address,
  onEdit,
  onRefresh,
}: Props) {

  async function handleDelete() {
    const user = auth.currentUser;
    if (!user) return;

    if (!confirm("Delete this address?")) return;

    // Step 5.3: Swapped window.location.reload() for await onRefresh()
    await deleteAddress(user.uid, address.id);
    await onRefresh();
  }

  async function makeDefault() {
    const user = auth.currentUser;
    if (!user) return;

    // Step 5.4: Swapped window.location.reload() for await onRefresh()
    await setDefaultAddress(user.uid, address.id);
    await onRefresh();
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
      <div className="flex justify-between mb-5">
        <div>
          <h2 className="text-xl font-bold text-white">
            {address.label}
            {address.isDefault && (
              <span className="ml-3 text-green-400 text-sm">
                ★ Default
              </span>
            )}
          </h2>
        </div>
      </div>

      <div className="space-y-1 text-slate-300">
        <p>{address.recipientName}</p>
        <p>{address.phone}</p>
        <p>{address.addressLine1}</p>
        {address.addressLine2 && <p>{address.addressLine2}</p>}
        <p>
          {address.city}, {address.state}
        </p>
        <p>{address.country}</p>
        <p>{address.postalCode}</p>
      </div>

      <div className="flex gap-3 mt-8 text-white">
        {!address.isDefault && (
          <button
            onClick={makeDefault}
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-xl"
          >
            Set Default
          </button>
        )}

        {/* Step 5.5: Added the onClick handler to the Edit button */}
        <button
          onClick={() => onEdit(address)}
          className="bg-yellow-600 hover:bg-yellow-700 px-4 py-2 rounded-xl"
        >
          Edit
        </button>

        <button
          onClick={handleDelete}
          className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-xl"
        >
          Delete
        </button>
      </div>
    </div>
  );
}