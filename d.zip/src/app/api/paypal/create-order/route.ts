import { NextResponse } from "next/server";

import {
  getPayPalAccessToken,
  PAYPAL_BASE,
} from "@/lib/paypal";

import { adminDb } from "@/lib/firebaseAdmin";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const requestId = body?.requestId;

    if (
      !requestId ||
      typeof requestId !== "string"
    ) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing or invalid requestId.",
        },
        {
          status: 400,
        }
      );
    }

    const requestSnapshot =
      await adminDb
        .collection("requests")
        .doc(requestId)
        .get();

    if (!requestSnapshot.exists) {
      return NextResponse.json(
        {
          success: false,
          error: "Request not found.",
        },
        {
          status: 404,
        }
      );
    }

    const request =
      requestSnapshot.data();

    if (!request) {
      return NextResponse.json(
        {
          success: false,
          error: "Request not found.",
        },
        {
          status: 404,
        }
      );
    }

    /*
     * Only requests waiting for payment
     * should be able to create a PayPal order.
     */
    if (
      request.status !==
      "awaiting_payment"
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "This request is not awaiting payment.",
        },
        {
          status: 400,
        }
      );
    }

    if (!request.quote) {
      return NextResponse.json(
        {
          success: false,
          error: "Quote not found.",
        },
        {
          status: 404,
        }
      );
    }

    /*
     * Check quote expiration on the server.
     */
    if (request.quote.expiresAt) {
      const expiresAt =
        request.quote.expiresAt.toDate();

      if (Date.now() >= expiresAt.getTime()) {
        return NextResponse.json(
          {
            success: false,
            error: "This quote has expired.",
          },
          {
            status: 400,
          }
        );
      }
    }

    const grandTotal =
      request.quote.breakdown
        ?.grandTotal;

    if (
      typeof grandTotal !== "number" ||
      !Number.isFinite(grandTotal) ||
      grandTotal <= 0
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Invalid payment amount.",
        },
        {
          status: 400,
        }
      );
    }

    const token =
      await getPayPalAccessToken();

    const response = await fetch(
      `${PAYPAL_BASE}/v2/checkout/orders`,
      {
        method: "POST",

        headers: {
          Authorization:
            `Bearer ${token}`,

          "Content-Type":
            "application/json",
        },

        body: JSON.stringify({
          intent: "CAPTURE",

          purchase_units: [
            {
              reference_id:
                requestId,

              custom_id:
                requestId,

              amount: {
                currency_code:
                  "USD",

                value:
                  grandTotal.toFixed(2),
              },
            },
          ],
        }),
      }
    );

    const order =
      await response.json();

    if (!response.ok) {
      console.error(
        "PayPal create order failed:",
        order
      );

      return NextResponse.json(
        {
          success: false,
          error:
            "PayPal failed to create the order.",
        },
        {
          status:
            response.status,
        }
      );
    }

    if (!order?.id) {
      return NextResponse.json(
        {
          success: false,
          error:
            "PayPal did not return an order ID.",
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json({
      success: true,
      orderId: order.id,
    });
  } catch (error) {
    console.error(
      "PayPal create-order error:",
      error
    );

    return NextResponse.json(
      {
        success: false,
        error:
          "Unable to create PayPal order.",
      },
      {
        status: 500,
      }
    );
  }
}