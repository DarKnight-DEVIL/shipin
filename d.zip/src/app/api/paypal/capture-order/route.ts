import { NextResponse } from "next/server";

import {
  getPayPalAccessToken,
  PAYPAL_BASE,
} from "@/lib/paypal";

import { adminDb } from "@/lib/firebaseAdmin";

import {
  FieldValue,
  Timestamp,
} from "firebase-admin/firestore";

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const requestId = body?.requestId;
    const orderID = body?.orderID;

    /*
     * Validate request ID
     */
    if (
      !requestId ||
      typeof requestId !== "string"
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Missing or invalid requestId.",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * Validate PayPal order ID
     */
    if (
      !orderID ||
      typeof orderID !== "string"
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Missing or invalid PayPal order ID.",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * Load request using Firebase Admin.
     *
     * This bypasses client Firestore security
     * rules because this is trusted server code.
     */
    const requestRef = adminDb
      .collection("requests")
      .doc(requestId);

    const requestSnapshot =
      await requestRef.get();

    if (!requestSnapshot.exists) {
      return NextResponse.json(
        {
          success: false,
          error: "Request not found.",
        },
        {
          status: 404,
        }
      );
    }

    const request =
      requestSnapshot.data();

    if (!request) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Request data not found.",
        },
        {
          status: 404,
        }
      );
    }

    /*
     * If Firestore already recorded payment,
     * don't attempt to capture again.
     */
    if (
      request.status === "paid" ||
      request.payment?.orderId === orderID
    ) {
      return NextResponse.json({
        success: true,
        status: "COMPLETED",
        alreadyPaid: true,
      });
    }

    if (!request.quote) {
      return NextResponse.json(
        {
          success: false,
          error: "Quote not found.",
        },
        {
          status: 400,
        }
      );
    }

    const expectedAmount =
      request.quote.breakdown
        ?.grandTotal;

    if (
      typeof expectedAmount !==
        "number" ||
      !Number.isFinite(
        expectedAmount
      ) ||
      expectedAmount <= 0
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Invalid expected payment amount.",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * Get PayPal server access token
     */
    const token =
      await getPayPalAccessToken();

    /*
     * Capture PayPal order
     */
    const response = await fetch(
      `${PAYPAL_BASE}/v2/checkout/orders/${orderID}/capture`,
      {
        method: "POST",

        headers: {
          Authorization:
            `Bearer ${token}`,

          "Content-Type":
            "application/json",
        },
      }
    );

    const result =
      await response.json();

    /*
     * Handle PayPal API errors
     */
    if (!response.ok) {
      console.error(
        "PayPal capture failed:",
        result
      );

      return NextResponse.json(
        {
          success: false,
          error:
            "PayPal failed to capture the payment.",
        },
        {
          status:
            response.status,
        }
      );
    }

    /*
     * Verify PayPal says the order
     * completed successfully.
     */
    if (
      result.status !==
      "COMPLETED"
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Payment was not completed.",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * Extract actual capture details
     */
    const capture =
      result.purchase_units?.[0]
        ?.payments?.captures?.[0];

    if (!capture) {
      return NextResponse.json(
        {
          success: false,
          error:
            "PayPal capture details were missing.",
        },
        {
          status: 400,
        }
      );
    }

    const capturedAmount =
      Number(
        capture.amount?.value
      );

    const capturedCurrency =
      capture.amount
        ?.currency_code;

    /*
     * Verify amount
     */
    const normalizedExpected =
      Number(
        expectedAmount.toFixed(2)
      );

    const normalizedCaptured =
      Number(
        capturedAmount.toFixed(2)
      );

    if (
      !Number.isFinite(
        capturedAmount
      ) ||
      normalizedCaptured !==
        normalizedExpected
    ) {
      console.error(
        "PayPal amount mismatch:",
        {
          expected:
            normalizedExpected,

          captured:
            normalizedCaptured,
        }
      );

      return NextResponse.json(
        {
          success: false,
          error:
            "Captured payment amount does not match the quote total.",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * Verify currency
     */
    if (
      capturedCurrency !== "USD"
    ) {
      return NextResponse.json(
        {
          success: false,
          error:
            "Unexpected payment currency.",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * Save payment information
     * directly using Firebase Admin.
     */
    await requestRef.update({
      status: "paid",

      payment: {
        provider: "paypal",

        orderId: orderID,

        captureId:
          capture.id,

        amount:
          capturedAmount,

        currency:
          capturedCurrency,

        paidAt:
          Timestamp.now(),
      },

      "statusHistory.paid":
        Timestamp.now(),

      updatedAt:
        FieldValue.serverTimestamp(),
    });

    /*
     * Create customer notification
     * using Firebase Admin.
     */
    if (request.userId) {
      await adminDb
        .collection("notifications")
        .add({
          userId:
            request.userId,

          requestId:
            requestId,

          title:
            "Payment Received",

          message:
            "We've received your payment and will begin purchasing your products.",

          type:
            "payment",

          read:
            false,

          createdAt:
            FieldValue.serverTimestamp(),
        });
    }

    /*
     * Successful response to frontend
     */
    return NextResponse.json({
      success: true,

      status:
        "COMPLETED",

      payment: {
        orderId:
          orderID,

        captureId:
          capture.id,

        amount:
          capturedAmount,

        currency:
          capturedCurrency,
      },
    });
  } catch (error) {
    console.error(
      "PayPal capture-order error:",
      error
    );

    return NextResponse.json(
      {
        success: false,

        error:
          "Unable to capture payment.",
      },
      {
        status: 500,
      }
    );
  }
}