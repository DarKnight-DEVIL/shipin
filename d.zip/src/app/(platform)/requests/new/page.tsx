"use client";

import AdditionalServices from "@/components/request/AdditionalServices";
import { useEffect, useState } from "react";
import { auth } from "@/lib/firebase";
import { getAddresses, addRequest } from "@/lib/firestore";
import AddressCard from "@/components/address/AddressCard";
import type { Address } from "@/types/address";

// Step 8.1: Imports added here
import Modal from "@/components/ui/Modal";
import AddressPicker from "@/components/address/AddressPicker";
import AddressForm from "@/components/address/AddressForm";
import { addAddress } from "@/lib/addressBook";

export default function NewRequestPage() {
  const [items, setItems] = useState([
    {
      name: "",
      url: "",
      quantity: 1,
    },
  ]);

  const [addresses, setAddresses] = useState<Address[]>([]);
  
  // Track the entire address object rather than just the string ID string
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);

  // Step 8.2: New states added below selectedAddress
  const [showAddressPicker, setShowAddressPicker] = useState(false);
  const [showAddAddress, setShowAddAddress] = useState(false);

  const [notes, setNotes] = useState("");

  // Additional Services states
  const [inspection, setInspection] = useState<"none" | "standard" | "detailed">("standard");
  const [shippingPreference, setShippingPreference] = useState<"auto" | "approval" | "hold">("approval");

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (!user) return;

      const data = await getAddresses(user.uid);
      setAddresses(data);

      // Load the Default Address
      if (data.length > 0) {
        const defaultAddress = data.find((a) => a.isDefault);
        setSelectedAddress(defaultAddress ?? data[0]);
      }
    });

    return () => unsubscribe();
  }, []);

  const addItem = () => {
    setItems([
      ...items,
      {
        name: "",
        url: "",
        quantity: 1,
      },
    ]);
  };

  const removeItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const updateItem = (index: number, field: string, value: string | number) => {
    const updated = [...items];
    updated[index] = {
      ...updated[index],
      [field]: value,
    };
    setItems(updated);
  };

  const handleAddressChange = (id: string) => {
    const found = addresses.find((a) => a.id === id);
    setSelectedAddress(found || null);
  };

  const submitRequest = async () => {
    const user = auth.currentUser;

    if (!user) {
      alert("Please login again.");
      return;
    }

    if (items.some((item) => !item.name || !item.url)) {
      alert("Please complete all item details.");
      return;
    }

    // Validation
    if (!selectedAddress) {
      alert("Please select an address.");
      return;
    }

    try {
      // Update the Submit Function
      await addRequest(
        {
          items,
          shippingAddress: selectedAddress,
          serviceSelections: {
            inspection,
            shippingPreference,
          },
          notes,
          email: user.email,
          customerName: user.displayName || "Customer",
        },
        user.uid
      );

      alert("Request submitted successfully!");

      setItems([
        {
          name: "",
          url: "",
          quantity: 1,
        },
      ]);
      setNotes("");
      setInspection("standard");
      setShippingPreference("approval");

      // Reset After Submission
      const updatedAddresses = await getAddresses(user.uid);
      setAddresses(updatedAddresses);
      const defaultAddress = updatedAddresses.find((a) => a.isDefault);
      setSelectedAddress(defaultAddress ?? updatedAddresses[0] ?? null);
      
    } catch (error) {
      console.error(error);
      alert("Failed to submit request.");
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto text-white">
      <h1 className="text-4xl font-bold text-white mb-2">Create Request</h1>

      <p className="text-slate-400 mb-8">
        Submit products you'd like ShipIN to purchase and forward to you.
      </p>

      {/* Items */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8">
        <h2 className="text-2xl font-semibold text-white mb-6">Items</h2>

        {items.map((item, index) => (
          <div key={index} className="border border-slate-800 rounded-xl p-4 mb-4">
            <h3 className="font-semibold text-white mb-4">Item {index + 1}</h3>

            <div className="grid md:grid-cols-3 gap-4">
              <input
                placeholder="Product Name"
                value={item.name}
                onChange={(e) => updateItem(index, "name", e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg p-3 text-white"
              />

              <input
                placeholder="Product URL"
                value={item.url}
                onChange={(e) => updateItem(index, "url", e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg p-3 text-white"
              />

              <input
                type="number"
                min="1"
                value={item.quantity}
                onChange={(e) => updateItem(index, "quantity", Number(e.target.value) || 0)}
                className="bg-slate-950 border border-slate-700 rounded-lg p-3 text-white"
              />
            </div>

            {items.length > 1 && (
              <button
                onClick={() => removeItem(index)}
                className="text-red-400 hover:text-red-300 mt-4"
              >
                Remove Item
              </button>
            )}
          </div>
        ))}

        <button
          onClick={addItem}
          className="text-purple-400 hover:text-purple-300 mt-4"
        >
          + Add Another Item
        </button>
      </div>

      {/* Replaced Address Section / Dropdown Block */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8">
        <h2 className="text-2xl font-semibold text-white mb-6">
          Delivery Address
        </h2>

        {addresses.length > 0 && (
          <div className="mb-4">
            <select
              value={selectedAddress?.id || ""}
              onChange={(e) => handleAddressChange(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white"
            >
              {addresses.map((address) => (
                <option key={address.id} value={address.id}>
                  {address.label || "Address"} ({address.recipientName} - {address.country})
                </option>
              ))}
            </select>
          </div>
        )}

        {selectedAddress ? (
          <div className="border border-slate-700 rounded-xl p-5">
            {/* Step 8.3: Updated to items-start layout and injected structural management action buttons */}
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold text-white">
                  {selectedAddress.label}
                  {selectedAddress.isDefault && (
                    <span className="ml-2 text-green-400">
                      ★ Default
                    </span>
                  )}
                </h3>

                <p className="text-slate-300 mt-3">
                  {selectedAddress.recipientName}
                </p>

                <p className="text-slate-400">
                  {selectedAddress.addressLine1}
                </p>

                {selectedAddress.addressLine2 && (
                  <p className="text-slate-400">
                    {selectedAddress.addressLine2}
                  </p>
                )}

                <p className="text-slate-400">
                  {selectedAddress.city}, {selectedAddress.state}
                </p>

                <p className="text-slate-400">
                  {selectedAddress.country}
                </p>

                <p className="text-slate-400">
                  {selectedAddress.postalCode}
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <button
                  onClick={() => setShowAddressPicker(true)}
                  className="bg-purple-600 hover:bg-purple-700 px-5 py-2 rounded-xl"
                >
                  Change Address
                </button>

                <button
                  onClick={() => setShowAddAddress(true)}
                  className="bg-slate-700 hover:bg-slate-600 px-5 py-2 rounded-xl"
                >
                  + New Address
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-slate-400">
            No saved address found.
          </div>
        )}
      </div>

      {/* Additional Services */}
      <div className="mb-8">
        <AdditionalServices
          inspection={inspection}
          shipping={shippingPreference}
          onInspectionChange={setInspection}
          onShippingChange={setShippingPreference}
        />
      </div>

      {/* Notes */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8">
        <h2 className="text-2xl font-semibold text-white mb-6">Additional Notes</h2>

        <textarea
          rows={5}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Optional notes for ShipIN..."
          className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white"
        />
      </div>

      {/* Notice */}
      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 mb-8 text-amber-300">
        Requests are automatically locked after submission. Any modifications require contacting ShipIN support.
      </div>

      <button
        onClick={submitRequest}
        className="bg-purple-600 hover:bg-purple-700 px-8 py-4 rounded-xl font-semibold transition"
      >
        Submit Request
      </button>

      {/* Step 8.4: Inline Address Picker Overlay Window Modal */}
      <Modal
        open={showAddressPicker}
        title="Select Address"
        onClose={() => setShowAddressPicker(false)}
      >
        <AddressPicker
          addresses={addresses}
          selected={selectedAddress ?? undefined}
          onSelect={(address) => {
            setSelectedAddress(address);
            setShowAddressPicker(false);
          }}
          onAddNew={() => {
            setShowAddressPicker(false);
            setShowAddAddress(true);
          }}
        />
      </Modal>

      {/* Step 8.5: Inline Address Creation Submission Form Modal */}
      <Modal
        open={showAddAddress}
        title="Add Address"
        onClose={() => setShowAddAddress(false)}
      >
        <AddressForm
          onSubmit={async (address) => {
            const user = auth.currentUser;
            if (!user) return;

            await addAddress(user.uid, address);
            
            const updated = await getAddresses(user.uid);
            setAddresses(updated);

            const newest = updated[updated.length - 1];
            setSelectedAddress(newest);
            setShowAddAddress(false);
          }}
        />
      </Modal>
    </div>
  );
}