"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { doc, updateDoc, onSnapshot } from "firebase/firestore";
import { db } from "@/lib/firebase";
import SupportCenter from "@/components/support/SupportCenter";
import { canCreateSupportTicket } from "@/lib/support";
import RequestHeader from "@/components/request/RequestHeader";
import RequestTimeline from "@/components/request/RequestTimeline";
import ProductsCard from "@/components/request/ProductsCard";
import QuoteCard from "@/components/request/QuoteCard";
import PaymentCard from "@/components/request/PaymentCard";
import type { Request } from "@/types/request";
import AddItemRequest from "@/components/request/AddItemRequest";

// Step 5: Imports added here
import QuoteCountdown from "@/components/request/QuoteCountdown";
import { isQuoteExpired } from "@/lib/quoteExpiry";

export default function RequestDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const requestId = params.id as string;

  const [request, setRequest] = useState<Request | null>(null);
  const [loading, setLoading] = useState(true);
  const [approving, setApproving] = useState(false);

  useEffect(() => {
    if (!requestId) return;

    const requestRef = doc(db, "requests", requestId);

    const unsubscribe = onSnapshot(
      requestRef,
      (snapshot) => {
        if (snapshot.exists()) {
          setRequest({
            id: snapshot.id,
            ...snapshot.data(),
          } as Request);
        } else {
          setRequest(null);
        }
        setLoading(false);
      },
      (error) => {
        console.error(error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [requestId]);

  const handleApproveQuote = async () => {
    if (!requestId) return;

    setApproving(true);

    try {
      const requestRef = doc(db, "requests", requestId);

      await updateDoc(requestRef, {
        status: "awaiting_payment",
      });

      router.push(`/payment/${requestId}`);
    } catch (error) {
      console.error(error);
      alert(
        error instanceof Error
          ? error.message
          : "Something went wrong approving the quote."
      );
    } finally {
      setApproving(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-white">Loading request...</div>;
  }

  if (!request) {
    return <div className="p-8 text-white">Request not found.</div>;
  }

  // Step 6: Quote expiration calculations and modified showAcceptQuote state
  const quoteExpired = isQuoteExpired(request.quote?.expiresAt);
  const showAcceptQuote = request.status === "review" && !quoteExpired;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      
      {/* Upgraded Native Modular Header */}
      <RequestHeader request={request} />

      {/* Integrated Modular Request Timeline Component */}
      <RequestTimeline status={request.status} />

      {/* Integrated Modular Tracking Card Component */}
      

      {/* Customer Shipment Tracking View - Hidden Carrier Details */}
      <section className="space-y-4">
        <h2 className="text-xl font-semibold text-white">
          Shipment
        </h2>

        {request.tracking?.internalTrackingId ? (
          <div className="rounded-xl border border-slate-700 bg-slate-900 p-4">
            <p className="text-sm text-slate-400">
              ShipIN Tracking ID
            </p>

            <p className="mt-1 text-lg font-semibold text-white">
              {request.tracking.internalTrackingId}
            </p>

            <p className="mt-2 text-xs text-slate-500">
              Use this tracking ID to track your shipment on ShipIN.
            </p>
          </div>
        ) : (
          <p className="text-slate-400 text-sm">
            Your shipment has not been dispatched yet.
          </p>
        )}
      </section>

      {/* Integrated Modular Products Card Component */}
      <ProductsCard
        items={request.items || []}
        quote={request.quote}
      />
      
      {/* Add Item To Existing Request */}
      <AddItemRequest
        request={request}
      />

      {/* Integrated Modular Quote Breakdown Card Component */}
      <QuoteCard quote={request.quote} />

      {/* Step 5: Conditional QuoteCountdown injection placed above the payment section */}
      {request.quote?.expiresAt && request.status === "review" && (
        <QuoteCountdown expiresAt={request.quote.expiresAt} />
      )}

      {/* Integrated Modular Payment Actions Card Component */}
      <PaymentCard
        request={request}
        onApproveQuote={handleApproveQuote}
        approving={approving}
      />

      {/* Step 7: Under the payment button / card element add the quoteExpired alerting banner block */}
      {quoteExpired && (
        <div className="mt-6 bg-red-500/10 border border-red-500/20 rounded-xl p-5">
          <h2 className="text-red-400 font-semibold">Quote Expired</h2>
          <p className="text-slate-400 mt-2">
            This quote is no longer valid. Please request a new quote.
          </p>
        </div>
      )}

      {/* Inspection Photos Gallery */}
      {request.warehouse?.inspectionPhotos &&
        request.warehouse.inspectionPhotos.length > 0 && (
          <div className="bg-slate-900 rounded-2xl p-6">
            <h2 className="text-xl font-semibold text-white mb-5">
              Inspection Photos
            </h2>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {request.warehouse.inspectionPhotos.map((photo) => (
                <img
                  key={photo}
                  src={photo}
                  alt="Inspection"
                  className="rounded-xl border border-slate-700 w-full object-cover aspect-video"
                />
              ))}
            </div>
          </div>
      )}

      {/* Support Module */}
      <SupportCenter
        requestId={request.id}
        customerId={request.userId}
        canCreateTicket={canCreateSupportTicket(request)}
      />
    </div>
  );
}